功能需求:
从零生成一个3D神经网络可视化应用，支持XOR、线性回归、圆形分类等问题的实时训练可视化。

约束条件:

1. 路径约束: 3D场景组件必须在src/components/scene/目录，神经网络可视化组件在src/components/network/目录
2. 命名约束: 3D神经网络节点组件必须以NeuronNode命名，连接线组件以SynapseLine命名
3. 3D要素要求: 必须实现坐标系统（神经元在3D空间网格布局）、动画（权重更新时的发光脉冲效果）、材质（神经元使用MeshStandardMaterial支持光照）
4. 技术约束: 必须使用@react-three/fiber和@react-three/drei，TensorFlow.js用于实时训练计算
5. Docker约束: 必须提供Dockerfile，使用Vite构建，Nginx托管，暴露80端口

验收标准: 1.实现3D神经网络层级结构可视化2.神经元节点支持悬停显示详细信息3.训练过程中权重变化实时反映在3D场景中4.支持切换XOR/线性回归/圆形分类三种问题5.提供Dockerfile且docker build -t nn-studio .构建成功6.容器启动后可通过http://localhost:8080访问
